from game import Agent, Directions, Actions
from util import manhattanDistance, PriorityQueue
import util
from search import SearchProblem, breadthFirstSearch, depthFirstSearch, uniformCostSearch

# Базовый класс для поиска пути к определенной позиции
class PositionSearchProblem(SearchProblem):
    """
    Реализует поиск пути от начальной позиции до целевой.
    Используется как основа для других поисковых задач.
    """
    def __init__(self, gameState, costFn=lambda x: 1, goal=None):
        self.walls = gameState.getWalls()
        self.startState = gameState.getPacmanPosition()
        
        if goal is None:
            food = gameState.getFood()
            self.goal = food.asList()[0] if food.count() > 0 else self.startState
        else:
            self.goal = goal
            
        self._visited = set()
        self._expanded = 0
        self.costFn = costFn

    def getStartState(self):
        return self.startState

    def isGoalState(self, state):
        return state == self.goal

    def getSuccessors(self, state):
        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
            x,y = state
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                nextState = (nextx, nexty)
                cost = self.costFn(nextState)
                successors.append((nextState, action, cost))
        self._expanded += 1
        return successors

    def getCostOfActions(self, actions):
        return len(actions)

# Класс для поиска всех точек с едой
class FoodSearchProblem(SearchProblem):
    """
    Реализует поиск пути для сбора всех точек с едой на карте.
    Состояние включает текущую позицию и оставшуюся еду.
    """
    def __init__(self, gameState):
        self.walls = gameState.getWalls()
        self.startState = gameState.getPacmanPosition()
        self.food = gameState.getFood()
        self._visited = set()
        self._expanded = 0

    def getStartState(self):
        return (self.startState, self.food)

    def isGoalState(self, state):
        return state[1].count() == 0

    def getSuccessors(self, state):
        pos, food = state
        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
            x,y = pos
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                nextFood = food.copy()
                nextFood[nextx][nexty] = False
                successors.append((((nextx, nexty), nextFood), action, 1))
        self._expanded += 1
        return successors

    def getCostOfActions(self, actions):
        return len(actions)

# Класс для поиска углов лабиринта
class CornersProblem(SearchProblem):
    """
    Реализует поиск пути для посещения всех углов лабиринта.
    Состояние включает текущую позицию и непосещенные углы.
    """
    def __init__(self, gameState):
        self.walls = gameState.getWalls()
        self.startState = gameState.getPacmanPosition()
        self.corners = ((1,1), (1,gameState.data.layout.height-2), 
                       (gameState.data.layout.width-2,1), 
                       (gameState.data.layout.width-2,gameState.data.layout.height-2))
        self._visited = set()
        self._expanded = 0

    def getStartState(self):
        return (self.startState, tuple(corner for corner in self.corners))

    def isGoalState(self, state):
        return len(state[1]) == 0

    def getSuccessors(self, state):
        pos, corners = state
        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
            x,y = pos
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                nextPos = (nextx, nexty)
                visitedCorners = list(corners)
                if nextPos in visitedCorners:
                    visitedCorners.remove(nextPos)
                successors.append(((nextPos, tuple(visitedCorners)), action, 1))
        self._expanded += 1
        return successors

    def getCostOfActions(self, actions):
        return len(actions)

# Базовый агент для выполнения поиска
class SearchAgent(Agent):
    """
    Общий агент, который использует различные алгоритмы поиска
    для нахождения пути к цели.
    """
    def __init__(self, fn='depthFirstSearch', prob='PositionSearchProblem', heuristic='nullHeuristic'):
        super(SearchAgent, self).__init__()
        
        if fn == 'depthFirstSearch' or fn == 'dfs':
            self.searchFunction = depthFirstSearch
        elif fn == 'breadthFirstSearch' or fn == 'bfs':
            self.searchFunction = breadthFirstSearch
        elif fn == 'uniformCostSearch' or fn == 'ucs':
            self.searchFunction = uniformCostSearch
        else:
            raise ValueError(f"Unknown search function: {fn}")
            
        if prob == 'PositionSearchProblem':
            self.searchType = PositionSearchProblem
        elif prob == 'StayEastSearchProblem':
            self.searchType = StayEastSearchProblem
        elif prob == 'StayWestSearchProblem':
            self.searchType = StayWestSearchProblem
        elif prob == 'FoodSearchProblem':
            self.searchType = FoodSearchProblem
        elif prob == 'CornersProblem':
            self.searchType = CornersProblem
        else:
            raise ValueError(f"Unknown problem type: {prob}")

        self.heuristic = util.lookup(heuristic, globals())

    def registerInitialState(self, gameState):
        problem = self.searchType(gameState)
        self.actions = self.searchFunction(problem)
        if not self.actions:
            self.actions = [Directions.STOP]

    def getAction(self, gameState):
        if not hasattr(self, 'actions') or len(self.actions) == 0:
            return Directions.STOP
        return self.actions.pop(0)

# Простейшая эвристика, всегда возвращает 0
def nullHeuristic(state, problem=None):
    """
    Нулевая эвристика - всегда возвращает 0.
    Используется как базовый случай для других эвристик.
    """
    return 0

# Эвристика для поиска еды
def foodHeuristic(state, problem=None):
    """
    Эвристика для задачи поиска еды.
    Возвращает максимальное манхэттенское расстояние до любой точки с едой.
    """
    position, foodGrid = state
    foodList = foodGrid.asList()
    if not foodList:
        return 0
    return max(manhattanDistance(position, food) for food in foodList)

# Эвристика для поиска углов
def cornersHeuristic(state, problem=None):
    """
    Эвристика для задачи поиска углов.
    Возвращает максимальное манхэттенское расстояние до любого непосещенного угла.
    """
    position, corners = state
    if not corners:
        return 0
    return max(manhattanDistance(position, corner) for corner in corners)

# Класс для поиска с предпочтением движения на восток
class StayEastSearchProblem(PositionSearchProblem):
    """
    Модифицированная задача поиска, где стоимость увеличивается
    при движении на запад.
    """
    def __init__(self, gameState, costFn=lambda x: 1, goal=None):
        super(StayEastSearchProblem, self).__init__(gameState, costFn, goal)
        self.costFn = lambda pos: 2 ** (gameState.data.layout.width - pos[0])

# Класс для поиска с предпочтением движения на запад
class StayWestSearchProblem(PositionSearchProblem):
    """
    Модифицированная задача поиска, где стоимость увеличивается
    при движении на восток.
    """
    def __init__(self, gameState, costFn=lambda x: 1, goal=None):
        super(StayWestSearchProblem, self).__init__(gameState, costFn, goal)
        self.costFn = lambda pos: 2 ** pos[0]

# Агент для движения на восток
class StayEastSearchAgent(SearchAgent):
    """
    Агент, использующий UCS для поиска пути с предпочтением
    движения на восток.
    """
    def __init__(self):
        super(StayEastSearchAgent, self).__init__(fn='uniformCostSearch', prob='StayEastSearchProblem')

# Агент для движения на запад
class StayWestSearchAgent(SearchAgent):
    """
    Агент, использующий UCS для поиска пути с предпочтением
    движения на запад.
    """
    def __init__(self):
        super(StayWestSearchAgent, self).__init__(fn='uniformCostSearch', prob='StayWestSearchProblem')

# Агент для поиска ближайшей точки
class ClosestDotSearchAgent(SearchAgent):
    """
    Агент, который ищет путь к ближайшей точке с едой.
    """
    def findPathToClosestDot(self, gameState):
        problem = PositionSearchProblem(gameState)
        return self.searchFunction(problem)