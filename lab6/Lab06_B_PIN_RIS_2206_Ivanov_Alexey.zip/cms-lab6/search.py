from util import Stack, Queue, PriorityQueue

from util import Stack, Queue, PriorityQueue

class SearchProblem:
    """
    Абстрактный класс для поисковых задач. 
    Наследуется и реализуется для конкретных задач (нахождение пути, поедание гранул и т.д.).
    """
    def getStartState(self):
        """Возвращает начальное состояние."""
        raise NotImplementedError

    def isGoalState(self, state):
        """Проверяет, является ли состояние целевым."""
        raise NotImplementedError

    def getSuccessors(self, state):
        """Возвращает список кортежей (next_state, action, step_cost)."""
        raise NotImplementedError

    def getCostOfActions(self, actions):
        """Вычисляет суммарную стоимость последовательности действий."""
        raise NotImplementedError

def depthFirstSearch(problem):
    """
    Реализация поиска в глубину (Depth-First Search).
    Использует стек для хранения вершин. Находит любой путь к цели (не обязательно оптимальный).

    Аргументы:
        problem -- экземпляр класса SearchProblem (например, PositionSearchProblem)

    Возвращает:
        Список действий для достижения цели или пустой список, если решение не найдено.
    """
    frontier = Stack()  # Стек для хранения (состояние, действия)
    frontier.push((problem.getStartState(), []))
    visited = set()     # Множество посещённых состояний

    while not frontier.isEmpty():
        state, actions = frontier.pop()
        
        # Проверка на достижение цели
        if problem.isGoalState(state):
            return actions
            
        # Раскрытие состояния, если оно не посещалось
        if state not in visited:
            visited.add(state)
            # Генерация преемников
            for next_state, action, _ in problem.getSuccessors(state):
                frontier.push((next_state, actions + [action]))
    
    return []  # Решение не найдено

def breadthFirstSearch(problem):
    """
    Реализация поиска в ширину (Breadth-First Search).
    Использует очередь для хранения вершин. Находит кратчайший путь по числу шагов.

    Аргументы:
        problem -- экземпляр класса SearchProblem

    Возвращает:
        Список действий для достижения цели или пустой список.
    """
    frontier = Queue()  # Очередь для хранения (состояние, действия)
    frontier.push((problem.getStartState(), []))
    visited = set()     # Множество посещённых состояний

    while not frontier.isEmpty():
        state, actions = frontier.pop()
        
        if problem.isGoalState(state):
            return actions
            
        if state not in visited:
            visited.add(state)
            for next_state, action, _ in problem.getSuccessors(state):
                frontier.push((next_state, actions + [action]))
    
    return []

def uniformCostSearch(problem):
    """
    Реализация поиска с равными ценами (Uniform-Cost Search).
    Использует приоритетную очередь для выбора состояния с минимальной суммарной стоимостью.
    Находит путь с наименьшей общей стоимостью.

    Аргументы:
        problem -- экземпляр класса SearchProblem

    Возвращает:
        Список действий для достижения цели или пустой список.
    """
    frontier = PriorityQueue()  # Приоритетная очередь: (приоритет, (состояние, действия, стоимость))
    frontier.push((problem.getStartState(), [], 0), 0)
    visited = set()

    while not frontier.isEmpty():
        state, actions, cost = frontier.pop()
        
        if problem.isGoalState(state):
            return actions
            
        if state not in visited:
            visited.add(state)
            for next_state, action, step_cost in problem.getSuccessors(state):
                new_actions = actions + [action]
                new_cost = cost + step_cost
                frontier.push((next_state, new_actions, new_cost), new_cost)
    
    return []